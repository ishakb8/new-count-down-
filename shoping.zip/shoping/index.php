<?php include "db.php"; ?>


<html>
	<head>
		<link rel="stylesheet" href="clockjscsss/flipclock.css">

		
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

		<script src="clockjscsss/flipclock.js"></script>	
	</head>
	<body>
    <table width="100%" border="0" border="2px">
    	<?php
		$sno = 1;
		$products_query = mysql_query("SELECT * FROM `products`");
		while($products_query_row = mysql_fetch_assoc($products_query))
		{
		 $startdate = $products_query_row['start_time'];
		 $enddate =$products_query_row['end_time'];
		 $startdate =date('Y/m/d H:i:s', strtotime($startdate)); 
		
		 $enddate =date('Y/m/d H:i:s', strtotime($enddate)); 
		
			?>
            <tr>
    <td>S.no</td>
    <td><?php echo $sno; ?></td>
  </tr>
  <tr>
    <td>Product name</td>
    <td><?php echo $products_query_row['product_name']; ?></td>
  </tr>
  <tr>
    <td>Image</td>
    <td><img src="uploads/<?php echo $products_query_row['product_img_name']; ?>"/></td>
  </tr>
  <tr>
    <td>Price</td>
    <td><?php echo $products_query_row['price']; ?></td>
  </tr>
  <tr>
    <td>Start Time</td>
    <td><?php echo $products_query_row['start_time']; ?></td>
  </tr>
  <tr>
    <td>End Time</td>
    <td><?php echo $products_query_row['end_time']; ?></td>
  </tr>
  <tr>
    <td>Time Left</td>
    <td><div class="clock" id="clock<?php echo $sno; ?>" style="margin:2em;"></div></td>
  </tr>
            
            <script type="text/javascript">
			var clock<?php echo $sno; ?>;

			$(document).ready(function() {

				// Grab the current date
				var currentDate<?php echo $sno; ?> = new Date("<?php echo $startdate; ?>");

				// Set some date in the future. In this case, it's always Jan 1
				var futureDate<?php echo $sno; ?>  = new Date("<?php echo $enddate; ?>");

				// Calculate the difference in seconds between the future and current date
				var diff<?php echo $sno; ?> = futureDate<?php echo $sno; ?>.getTime() / 1000 - currentDate<?php echo $sno; ?>.getTime() / 1000;

				// Instantiate a coutdown FlipClock
				clock<?php echo $sno; ?> = $('#clock<?php echo $sno; ?>').FlipClock(diff<?php echo $sno; ?>, {
					clockFace: 'DailyCounter',
					countdown: true
				});
			});
		</script>
            <?php
			$sno++;
		}
		
		?>
	
        
     </table>
            
		
		
	</body>
</html>