-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 01, 2015 at 05:46 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `shop`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `id` int(11) NOT NULL auto_increment,
  `product_name` varchar(60) NOT NULL,
  `product_img_name` varchar(60) NOT NULL,
  `price` int(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` VALUES (1, 'Android Phone FX1', 'android-phone.jpg', 201, '01:00:00', '03:00:00');
INSERT INTO `products` VALUES (2, 'Television DXT', 'lcd-tv.jpg', 501, '01:00:00', '04:00:00');
INSERT INTO `products` VALUES (3, 'External Hard Disk', 'external-hard-disk.jpg', 100, '01:00:00', '05:00:00');
INSERT INTO `products` VALUES (4, 'Wrist Watch GE2', 'wrist-watch.jpg', 400, '02:00:00', '02:59:00');
