<?php
include "../db.php";
extract($_POST);
extract($_GET);
define ("MAX_SIZE","1000"); 
function getExtension($str)
{
	 $i = strrpos($str,".");
	 if (!$i) { return ""; }
	 $l = strlen($str) - $i;
	 $ext = substr($str,$i+1,$l);
	 return $ext;
}

if(isset($_POST) && $_POST['Submit']=="Submit")
{
	
	$errors=0;
	$s_image=$_FILES['image']['name'];
	
	if( isset($_FILES['image']['name']) )
	{
		$filename = stripslashes($_FILES['image']['name']);
		$extension = getExtension($filename);
		$extension = strtolower($extension);
		if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") 
			&& ($extension != "gif")&& ($extension != "JPG") && ($extension != "JPEG") 
			&& ($extension != "PNG") && ($extension != "GIF")) 
		{
			echo '<h3>Unknown extension!</h3>';
			$errors=1;
		}
		else
		{
			
			$size=filesize($_FILES['image']['tmp_name']);
	 
			if ($size > MAX_SIZE*1024)
			{
				echo '<h4>You have exceeded the size limit!</h4>';
				$errors=1;
			}
	 
			$image_name=time().'.'.$extension;
			$newname="../uploads/".$image_name;
	 
			$copied = copy($_FILES['image']['tmp_name'], $newname);
			if (!$copied) 
			{
				echo '<h3>Copy unsuccessfull!</h3>';
				$errors=1;
			}

	mysql_query("INSERT INTO `products`(`product_name`,`price`,`start_time`,`end_time`,`product_img_name`) VALUES('$name','$price','$starttime','$endtime','$image_name')");
	
	
}
}
}
?>


<form name="form1" method="post" action="" enctype="multipart/form-data">
<table width="50%" border="0" align="center">
  <tr>
    <td width="26%">Name</td>
    
    <td width="74%"><input type="text" name="name" ></td>
  </tr>
  <tr>
    <td>Price</td>

    <td><input type="text" name="price" ></td>
  </tr>
  <tr>
    <td>Image</td>
   
    <td><input type="file" name="image" ></td>
  </tr>

  <tr>
    <td>Start Time</td>

    <td><input type="time" name="starttime" ></td>
  </tr>
  <tr>
    <td>End Time</td>

    <td><input type="time" name="endtime" ></td>
  </tr>
  <tr>
    <td colspan="3"><div align="left">
      <input type="submit" name="Submit" value="Submit">
    </div></td>
  
  </tr>
</table>
</form>
